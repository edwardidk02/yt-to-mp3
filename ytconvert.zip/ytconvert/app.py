import sqlite3
import os
import sys
import subprocess

# --- 1. AUTO-INSTALLER SECTION ---
def install_dependencies():
    packages = ["yt-dlp", "imageio-ffmpeg", "flask"]
    for package in packages:
        try:
            __import__(package.replace("-", "_"))
        except ImportError:
            print(f"Installing {package}... please wait.")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

install_dependencies()


# --- 2. IMPORTS ---
import yt_dlp
import imageio_ffmpeg
from flask import Flask, render_template, request, send_file, after_this_request, session, redirect, url_for

def get_db_connection():
    conn = sqlite3.connect('databases.db')
    conn.row_factory = sqlite3.Row
    return conn

get_db_connection()

app = Flask(__name__)

# safer secret key
app.secret_key = os.urandom(24)

# --- 3. DYNAMIC PATHS & SETUP ---
DOWNLOAD_FOLDER = 'downloads'
if not os.path.exists(DOWNLOAD_FOLDER):
    os.makedirs(DOWNLOAD_FOLDER)

# optional: clean old files on startup
for f in os.listdir(DOWNLOAD_FOLDER):
    try:
        os.remove(os.path.join(DOWNLOAD_FOLDER, f))
    except:
        pass

FFMPEG_EXE = imageio_ffmpeg.get_ffmpeg_exe()
print(f"Success! Running with FFmpeg from: {FFMPEG_EXE}")

# --- 4. FLASK ROUTES ---
@app.route('/')
def forward():
    return redirect(url_for('home'))

@app.route('/home')
def home():
    return render_template('home.html', theme=session.get('theme', 'dark'))

@app.route('/toggle-theme', methods=['POST'])
def toggle_theme():
    if session.get('theme') == 'light':
        session['theme'] = 'dark'
    else:
        session['theme'] = 'light'
    return redirect(request.referrer or url_for('home'))

@app.route('/converter')
def index():
    return render_template('index.html', theme=session.get('theme', 'dark'))

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['Name']
        email = request.form['Email']
        nummer = request.form['Nummer']

        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Matching 3 columns with 3 placeholders and 3 variables
        cursor.execute("INSERT INTO gebruikers (naam, email, nummer) VALUES (?, ?, ?)", 
                    (name, email, nummer))
        
        conn.commit()
        conn.close()

        return f"gebruiker {name} is succesvol geregistreerd"
    return render_template('contact.html', theme=session.get('theme', 'dark'))

@app.route('/convert', methods=['POST'])
def convert():
    video_url = request.form.get('url')

    if not video_url:
        return "Error: No URL provided"

    ydl_opts = {
        'ffmpeg_location': FFMPEG_EXE,
        'format': 'bestaudio/best',
        'restrictfilenames': True,
        'noplaylist': True,
        'http_headers': {
            'User-Agent': 'Mozilla/5.0'
        },
        # 🔥 OPTIONAL but recommended (fixes YouTube blocking)
        # Put cookies.txt in your project folder
        # 'cookiefile': 'cookies.txt',

        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        # prevents duplicate filename crashes
        'outtmpl': os.path.join(DOWNLOAD_FOLDER, '%(title)s_%(id)s.%(ext)s'),
        'quiet': True
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(video_url, download=True)

            if 'requested_downloads' in info:
                filename = info['requested_downloads'][0]['filepath']
            else:
                filename = ydl.prepare_filename(info).rsplit('.', 1)[0] + '.mp3'

        if not os.path.exists(filename):
            return f"Error: File not found: {filename}"

        response = send_file(filename, as_attachment=True)

        @after_this_request
        def remove_file(response):
            try:
                os.remove(filename)
            except Exception as e:
                print(f"Error deleting file: {e}")
            return response

        return response

    except Exception as e:
        return f"An error occurred: {str(e)}"

@app.route('/about')
def about():
    return render_template('about.html', theme=session.get('theme', 'dark'))

if __name__ == '__main__':
    app.run(debug=True)