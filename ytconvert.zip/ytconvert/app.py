import os
import sys
import subprocess

# --- 1. AUTO-INSTALLER SECTION ---
def install_dependencies():
    packages = ["yt-dlp", "imageio-ffmpeg", "flask"]
    for package in packages:
        try:
            __import__(package.replace("-", "_"))
        except ImportError:
            print(f"Installing {package}... please wait.")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

install_dependencies()

# --- 2. IMPORTS ---
import yt_dlp
import imageio_ffmpeg
# ADDED: session, redirect, and url_for to the import line
from flask import Flask, render_template, request, send_file, after_this_request, session, redirect, url_for

app = Flask(__name__)

# ADDED: Secret key is REQUIRED to use sessions for the light/dark mode
app.secret_key = 'some_unique_and_secret_key_123'

# --- 3. DYNAMIC PATHS & SETUP ---
DOWNLOAD_FOLDER = 'downloads'
if not os.path.exists(DOWNLOAD_FOLDER):
    os.makedirs(DOWNLOAD_FOLDER)

FFMPEG_EXE = imageio_ffmpeg.get_ffmpeg_exe()
print(f"Success! Running with FFmpeg from: {FFMPEG_EXE}")

# --- 4. FLASK ROUTES ---
@app.route('/')
def home():
    # FIXED: Uses session.get('theme') to match your toggle logic
    current_theme = session.get('theme', 'dark')
    return render_template('base.html', theme=current_theme)

@app.route('/toggle-theme', methods=['POST'])
def toggle_theme():
    # FIXED: Logic to switch between 'dark' and 'light'
    if session.get('theme') == 'light':
        session['theme'] = 'dark'
    else:
        session['theme'] = 'light'
    return redirect(request.referrer or url_for('home'))

@app.route('/converter')
def index():
    # ADDED: Pass theme here too so the converter page stays in light/dark mode
    return render_template('index.html', theme=session.get('theme', 'dark'))

@app.route('/contact')
def contact():
    # ADDED: Pass theme here too
    return render_template('contact.html', theme=session.get('theme', 'dark'))

@app.route('/convert', methods=['POST'])
def convert():
    video_url = request.form.get('url')
    
    ydl_opts = {
        'ffmpeg_location': FFMPEG_EXE,
        'format': 'bestaudio/best',
        'restrictfilenames': True,
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'outtmpl': os.path.join(DOWNLOAD_FOLDER, '%(title)s.%(ext)s'),
        'quiet': True
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(video_url, download=True)
            if 'requested_downloads' in info:
                filename = info['requested_downloads'][0]['filepath']
            else:
                filename = ydl.prepare_filename(info).rsplit('.', 1)[0] + '.mp3'

        if not os.path.exists(filename):
             return f"Error: File was downloaded but could not be located at: {filename}"

        @after_this_request
        def remove_file(response):
            return response

        return send_file(filename, as_attachment=True)

    except Exception as e:
        return f"An error occurred: {str(e)}"

if __name__ == '__main__':
    app.run(debug=True)